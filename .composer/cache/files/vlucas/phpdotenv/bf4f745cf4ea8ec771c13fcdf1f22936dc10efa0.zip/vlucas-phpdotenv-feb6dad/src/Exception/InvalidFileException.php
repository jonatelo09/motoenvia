<?php

namespace Dotenv\Exception;

use InvalidArgumentException;

class InvalidFileException extends InvalidArgumentException implements ExceptionInterface
{
    //
}
